package com.nuvsoft.android.scanner.listeners;

public class FineLocationListener {	
}
